import React, { useState, useEffect } from 'react';
import { ShoppingCart, Menu, X, Bike } from 'lucide-react';
import Container from '../ui/Container';
import Button from '../ui/Button';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <Container>
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Bike className={`h-8 w-8 ${isScrolled ? 'text-blue-600' : 'text-blue-600'}`} />
            <span className={`ml-2 text-xl font-bold ${isScrolled ? 'text-gray-900' : 'text-white'}`}>
              VeloElite
            </span>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <NavLink isScrolled={isScrolled} href="#" label="Home" />
            <NavLink isScrolled={isScrolled} href="#shop" label="Shop" />
            <NavLink isScrolled={isScrolled} href="#featured" label="Featured" />
            <NavLink isScrolled={isScrolled} href="#about" label="About" />
            <NavLink isScrolled={isScrolled} href="#contact" label="Contact" />
          </nav>
          
          {/* Cart & Mobile Menu Button */}
          <div className="flex items-center space-x-4">
            <button 
              className={`p-2 rounded-full hover:bg-gray-100 transition-colors ${
                isScrolled ? 'text-gray-700' : 'text-white'
              }`}
            >
              <ShoppingCart className="h-6 w-6" />
            </button>
            
            <div className="md:hidden">
              <button 
                onClick={toggleMenu}
                className={`p-2 rounded-full hover:bg-gray-100 transition-colors ${
                  isScrolled ? 'text-gray-700' : 'text-white'
                }`}
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
            
            <div className="hidden md:block">
              <Button variant="primary" size="md">
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </Container>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="absolute top-full left-0 right-0 bg-white shadow-lg md:hidden">
          <div className="py-3 px-4 space-y-3">
            <MobileNavLink href="#" label="Home" />
            <MobileNavLink href="#shop" label="Shop" />
            <MobileNavLink href="#featured" label="Featured" />
            <MobileNavLink href="#about" label="About" />
            <MobileNavLink href="#contact" label="Contact" />
            <div className="pt-2">
              <Button variant="primary" size="md" className="w-full">
                Sign In
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

type NavLinkProps = {
  href: string;
  label: string;
  isScrolled: boolean;
};

const NavLink: React.FC<NavLinkProps> = ({ href, label, isScrolled }) => {
  return (
    <a 
      href={href} 
      className={`font-medium transition-colors hover:text-blue-600 ${
        isScrolled ? 'text-gray-700' : 'text-white'
      }`}
    >
      {label}
    </a>
  );
};

type MobileNavLinkProps = {
  href: string;
  label: string;
};

const MobileNavLink: React.FC<MobileNavLinkProps> = ({ href, label }) => {
  return (
    <a 
      href={href} 
      className="block py-2 px-3 font-medium text-gray-700 hover:bg-gray-100 rounded-md"
    >
      {label}
    </a>
  );
};

export default Header;