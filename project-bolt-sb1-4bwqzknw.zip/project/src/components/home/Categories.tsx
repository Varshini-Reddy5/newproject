import React from 'react';
import Container from '../ui/Container';

type Category = {
  id: string;
  name: string;
  description: string;
  image: string;
};

const categories: Category[] = [
  {
    id: 'mountain',
    name: 'Mountain Bikes',
    description: 'Designed for off-road cycling on rough terrain',
    image: 'https://images.pexels.com/photos/100582/pexels-photo-100582.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: 'road',
    name: 'Road Bikes',
    description: 'Built for speed on paved roads and racing',
    image: 'https://images.pexels.com/photos/2158963/pexels-photo-2158963.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: 'hybrid',
    name: 'Hybrid Bikes',
    description: 'Versatile bikes for commuting and leisure',
    image: 'https://images.pexels.com/photos/1149601/pexels-photo-1149601.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: 'electric',
    name: 'Electric Bikes',
    description: 'Motor-assisted bikes for easier rides',
    image: 'https://images.pexels.com/photos/3662757/pexels-photo-3662757.jpeg?auto=compress&cs=tinysrgb&w=600'
  }
];

const Categories: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Explore Categories</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Find the perfect bike for your style and needs from our diverse collection of categories.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </Container>
    </section>
  );
};

type CategoryCardProps = {
  category: Category;
};

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <div className="group relative overflow-hidden rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 h-80">
      <div 
        className="absolute inset-0 bg-cover bg-center transform group-hover:scale-110 transition-transform duration-700"
        style={{ backgroundImage: `url(${category.image})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/20"></div>
      </div>
      
      <div className="relative h-full flex flex-col justify-end p-6 text-white">
        <h3 className="text-xl font-bold mb-2">{category.name}</h3>
        <p className="text-gray-200 mb-4 opacity-90">{category.description}</p>
        <a 
          href={`#${category.id}`} 
          className="inline-flex items-center text-sm font-medium text-white hover:text-blue-300 transition-colors"
        >
          Explore Collection
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-4 w-4 ml-1 transform group-hover:translate-x-1 transition-transform" 
            viewBox="0 0 20 20" 
            fill="currentColor"
          >
            <path 
              fillRule="evenodd" 
              d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" 
              clipRule="evenodd" 
            />
          </svg>
        </a>
      </div>
    </div>
  );
};

export default Categories;