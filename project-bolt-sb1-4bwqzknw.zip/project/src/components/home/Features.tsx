import React from 'react';
import { Truck, CheckCircle, RotateCcw, Clock, Headset as HeadsetMic } from 'lucide-react';
import Container from '../ui/Container';

type Feature = {
  icon: React.ReactNode;
  title: string;
  description: string;
};

const features: Feature[] = [
  {
    icon: <Truck className="h-8 w-8 text-blue-600" />,
    title: 'Free Shipping',
    description: 'Free shipping on all orders above $500'
  },
  {
    icon: <CheckCircle className="h-8 w-8 text-blue-600" />,
    title: 'Quality Guarantee',
    description: 'All bikes come with a 2-year warranty'
  },
  {
    icon: <RotateCcw className="h-8 w-8 text-blue-600" />,
    title: 'Easy Returns',
    description: '30-day hassle-free return policy'
  },
  {
    icon: <Clock className="h-8 w-8 text-blue-600" />,
    title: 'Same-Day Dispatch',
    description: 'Orders placed before 2 PM ship same day'
  },
  {
    icon: <HeadsetMic className="h-8 w-8 text-blue-600" />,
    title: 'Expert Support',
    description: 'Professional advice from cycling experts'
  }
];

const Features: React.FC = () => {
  return (
    <section className="py-12 bg-white border-t border-gray-100">
      <Container>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="flex flex-col items-center text-center"
            >
              <div className="mb-4">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-gray-600">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
};

export default Features;