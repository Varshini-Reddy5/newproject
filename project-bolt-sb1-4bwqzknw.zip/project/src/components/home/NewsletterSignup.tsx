import React, { useState } from 'react';
import Container from '../ui/Container';
import Button from '../ui/Button';

const NewsletterSignup: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, you would submit to an API
    console.log('Submitted email:', email);
    
    // Show success state
    setIsSubmitted(true);
    
    // Reset form
    setEmail('');
    
    // Reset success message after 5 seconds
    setTimeout(() => {
      setIsSubmitted(false);
    }, 5000);
  };

  return (
    <section className="py-12 bg-blue-600">
      <Container>
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white mb-3">Join Our Newsletter</h2>
          <p className="text-blue-100 max-w-2xl mx-auto mb-6">
            Subscribe to get special offers, exclusive discounts, and updates on new arrivals.
          </p>
          
          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-grow px-4 py-3 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-300"
              />
              <Button 
                type="submit" 
                variant="secondary" 
                size="md"
                className="whitespace-nowrap"
              >
                Subscribe
              </Button>
            </div>
            
            {isSubmitted && (
              <p className="mt-3 text-sm text-white bg-blue-500 py-2 px-4 rounded-md inline-block">
                Thanks for subscribing!
              </p>
            )}
            
            <p className="mt-4 text-xs text-blue-200">
              By subscribing, you agree to our Privacy Policy and consent to receive updates from our company.
            </p>
          </form>
        </div>
      </Container>
    </section>
  );
};

export default NewsletterSignup;