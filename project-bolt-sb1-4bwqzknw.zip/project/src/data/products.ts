import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Carbon Elite Mountain Bike',
    description: 'Professional-grade mountain bike with carbon frame and premium suspension.',
    price: 2499.99,
    discount: 10,
    image: 'https://images.pexels.com/photos/100582/pexels-photo-100582.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Mountain Bikes',
    brand: 'VeloElite',
    rating: 4.9,
    inStock: true
  },
  {
    id: '2',
    name: 'SpeedMaster Road Bike',
    description: 'Lightweight road bike designed for speed and performance.',
    price: 1899.99,
    discount: 0,
    image: 'https://images.pexels.com/photos/2158963/pexels-photo-2158963.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Road Bikes',
    brand: 'VeloElite',
    rating: 4.8,
    inStock: true
  },
  {
    id: '3',
    name: 'Urban Commuter Hybrid',
    description: 'Versatile hybrid bike perfect for city commuting and weekend trails.',
    price: 899.99,
    discount: 5,
    image: 'https://images.pexels.com/photos/1149601/pexels-photo-1149601.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Hybrid Bikes',
    brand: 'CityRider',
    rating: 4.6,
    inStock: true
  },
  {
    id: '4',
    name: 'E-Power Electric Bike',
    description: 'Powerful electric bike with long-lasting battery and smooth ride.',
    price: 2199.99,
    discount: 0,
    image: 'https://images.pexels.com/photos/3662757/pexels-photo-3662757.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Electric Bikes',
    brand: 'EcoMotion',
    rating: 4.7,
    inStock: true
  }
];