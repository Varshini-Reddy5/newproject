export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  discount: number;
  image: string;
  category: string;
  brand: string;
  rating: number;
  inStock: boolean;
};