import React from 'react';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Hero from './components/home/Hero';
import FeaturedProducts from './components/home/FeaturedProducts';
import Categories from './components/home/Categories';
import Testimonials from './components/home/Testimonials';
import NewsletterSignup from './components/home/NewsletterSignup';
import Features from './components/home/Features';
import { products } from './data/products';

function App() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        <Hero />
        <Features />
        <Categories />
        <FeaturedProducts products={products} />
        <Testimonials />
        <NewsletterSignup />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;